const getters = {
    isConnected: state => state.app.isConnected,
    account: state => state.app.account,
}
export default getters
